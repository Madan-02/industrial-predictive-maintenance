# Test Cases

These are expected outcomes from the code's rules, not evidence that automated tests have already run.

| ID | Temperature | Vibration | Load | Score | Expected status |
|---|---:|---:|---:|---:|---|
| TC01 | 30 °C | 5 | 20% | 0 | NORMAL |
| TC02 | 55 °C | 5 | 20% | 20 | NORMAL |
| TC03 | 75 °C | 5 | 20% | 35 | NORMAL |
| TC04 | 30 °C | 15 | 20% | 20 | NORMAL |
| TC05 | 30 °C | 25 | 20% | 35 | NORMAL |
| TC06 | 30 °C | 5 | 65% | 20 | NORMAL |
| TC07 | 55 °C | 15 | 20% | 40 | CRITICAL |
| TC08 | 75 °C | 25 | 20% | 70 | FAULT |
| TC09 | 30 °C | 25 | 85% | 65 | CRITICAL |
| TC10 | 55 °C | 25 | 85% | 85 | FAULT |

## Manual procedure
1. Run Wokwi and open Serial Monitor at 115200 baud.
2. Adjust only one potentiometer at a time; verify the corresponding reading changes.
3. Try inputs that create NORMAL, CRITICAL, and FAULT scores.
4. At FAULT, check red LED, buzzer, EN HIGH, and relay output LOW.
5. Press the reset button and confirm monitoring resumes.

Values are illustrative. Motor-stop behavior depends on actual simulated wiring and driver configuration.
