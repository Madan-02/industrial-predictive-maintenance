# Smart Embedded System for Industrial Machine Health Monitoring and Predictive Maintenance

A Wokwi simulation prototype using ESP32 and three potentiometers to simulate temperature, vibration, and load. It calculates a rule-based anomaly score and controls status LEDs, a buzzer, a relay output, and a stepper-driver enable signal.

**Wokwi project:** https://wokwi.com/projects/477233192323085313

> This repository describes the supplied simulation code. It does not claim physical hardware has been built or tested. The current system uses threshold rules, not a trained AI model.

## Features
- Simulated temperature, vibration, and load inputs.
- Threshold-based anomaly score.
- Green LED for normal status; red LED for critical/fault status.
- Score >= 70 latches a fault, sets EN HIGH, relay LOW, and activates the buzzer.
- Pushbutton on GPIO32 resets the fault.

## Pin mapping

| Function | GPIO | Notes |
|---|---:|---|
| Temperature potentiometer | 35 | Scaled to 20–100 °C |
| Vibration potentiometer | 34 | Scaled to 0–30 arbitrary units |
| Load potentiometer | 33 | Scaled to 0–100% |
| STEP | 25 | Stepper-driver STEP signal |
| EN | 27 | Assumes LOW enables and HIGH disables driver |
| Relay | 23 | Assumes HIGH = run, LOW = off |
| Buzzer | 4 | 2 kHz tone during fault |
| Red LED | 16 | Critical/fault |
| Green LED | 17 | Normal |
| Reset button | 32 | INPUT_PULLUP; press connects pin to GND |

The sketch pulses STEP but does not set a DIR pin. Direction depends on the Wokwi wiring/input state.

## Run in Wokwi
1. Open the [Wokwi project](https://wokwi.com/projects/477233192323085313).
2. Check that the diagram wiring matches the pin table.
3. Use `src/main.ino` as the ESP32 sketch.
4. Start simulation and open Serial Monitor at **115200 baud**.
5. Move each potentiometer independently and observe readings, score, LEDs, and fault response.
6. Press the reset button to clear a latched fault.

The actual Wokwi `diagram.json` was not supplied with the code, so copy that file from your project into the repository if you want the wiring diagram included.

## Score rules

| Input | Threshold | Points |
|---|---|---:|
| Temperature | 50–69 °C | 20 |
| Temperature | >= 70 °C | 35 |
| Vibration | 10–19 | 20 |
| Vibration | >= 20 | 35 |
| Load | 60–79% | 20 |
| Load | >= 80% | 30 |

Each input contributes only its highest matching score.

- **NORMAL:** 0–39
- **CRITICAL:** 40–69; red LED on, buzzer off, motor continues
- **FAULT:** 70 or more; driver disabled, relay output set LOW, red LED and buzzer on until reset

Thresholds are for demonstration, not validated industrial safety limits.

## Environment variables
None are required. No API keys or cloud services are used.

## Limitations and safety
- Potentiometers simulate sensor readings; they are not real sensors.
- Load is a simulated percentage, not a direct physical load measurement.
- Relay polarity and driver wiring must be verified in the actual diagram.
- Do not use this prototype as an industrial safety controller.
- In the fault state, sensor readings stop updating until reset.
- Physical motor stopping depends on the actual driver and relay wiring.

See `docs/architecture.md`, `data/sample_sensor_data.csv`, and `tests/test_cases.md`.
