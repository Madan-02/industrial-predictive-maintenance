# Technical Design Document

## Purpose
This document describes the supplied ESP32/Wokwi rule-based monitoring prototype. Potentiometers simulate temperature, vibration, and load inputs.

## Architecture diagram

```mermaid
flowchart TD
    A[Temperature pot GPIO35] --> E[ESP32]
    B[Vibration pot GPIO34] --> E
    C[Load pot GPIO33] --> E
    E --> D[Scale ADC readings]
    D --> F[Threshold-based score]
    F --> G{Score}
    G -->|0-39| H[Normal: green LED]
    G -->|40-69| I[Critical: red LED]
    G -->|70+| J[Latched fault]
    J --> K[EN HIGH: driver disabled]
    J --> L[Relay LOW]
    J --> M[Red LED and 2 kHz buzzer]
    N[Reset button GPIO32] --> O[Clear fault]
    O --> E
    E --> P[STEP pulses GPIO25]
    E --> Q[Serial Monitor 115200 baud]
```

## Pin allocation
- GPIO35: temperature potentiometer, scaled to 20–100 °C.
- GPIO34: vibration potentiometer, scaled to 0–30 arbitrary units.
- GPIO33: load potentiometer, scaled to 0–100%.
- GPIO25: STEP output.
- GPIO27: driver enable.
- GPIO23: relay output.
- GPIO4: buzzer.
- GPIO16: red LED.
- GPIO17: green LED.
- GPIO32: active-low reset button using `INPUT_PULLUP`.

## Scoring
Temperature adds 20 at 50–69 °C and 35 at 70 °C or above. Vibration adds 20 at 10–19 and 35 at 20 or above. Load adds 20 at 60–79% and 30 at 80% or above.

Score bands: 0–39 normal; 40–69 critical; 70+ fault. Fault state disables the driver, sets relay LOW, turns on red LED and buzzer, and stops sensor updates until reset.

## Known gaps
1. STEP is pulsed, but no DIR pin is configured by this sketch.
2. Relay polarity is assumed to be HIGH=run and LOW=off; verify the module/wiring.
3. Inputs are simulated and not calibrated physical measurements.
4. This is rule-based logic, not a trained AI model.
5. Critical status (40–69) does not stop the motor.
6. Fault behavior must be verified against the actual Wokwi diagram.

## Verification
Follow the manual scenarios in `../tests/test_cases.md`; confirm each potentiometer changes only its own reading, test all score bands, and test fault/reset behavior.
